package networks;

import javafx.scene.canvas.Canvas;

/**
 * TODO: Either implement this class or replace it by a different class (depending on your design).
 */
public class Network {
    public void draw(Canvas destination) { }
}
